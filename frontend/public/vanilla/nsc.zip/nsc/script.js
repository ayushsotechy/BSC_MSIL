(function () {
  const params = new URLSearchParams(window.location.search);

  const demoScores = [
    { id: 'nsc-1', zone: 'NORTH', region: 'NORTH 1', dealerCode: 'NORTH 1AKANS', dealerName: 'AKANKSHA (M)', month: 'June', year: '2029', provisionalBand: 'NO BAND', evaluatedPoints: '0' },
    { id: 'nsc-2', zone: 'EAST', region: 'EAST 3', dealerCode: 'EAST 3JAYBE', dealerName: 'JAYBEE', month: 'June', year: '2029', provisionalBand: 'NO BAND', evaluatedPoints: '0' },
    { id: 'nsc-3', zone: 'EAST', region: 'EAST 3', dealerCode: 'EAST 3MTLAZ', dealerName: 'MITTAL AUTOZONE', month: 'June', year: '2029', provisionalBand: 'NO BAND', evaluatedPoints: '0' },
    { id: 'nsc-4', zone: 'EAST', region: 'EAST 3', dealerCode: 'EAST 3PALLA', dealerName: 'PALLAVI', month: 'June', year: '2029', provisionalBand: 'NO BAND', evaluatedPoints: '0' },
    { id: 'nsc-5', zone: 'EAST', region: 'EAST 3', dealerCode: 'EAST 3PODDR', dealerName: 'PODDAR', month: 'June', year: '2029', provisionalBand: 'NO BAND', evaluatedPoints: '0' },
    { id: 'nsc-6', zone: 'EAST', region: 'EAST 3', dealerCode: 'EAST 3PROGR', dealerName: 'PROGRESSIVE', month: 'June', year: '2029', provisionalBand: 'NO BAND', evaluatedPoints: '0' },
    { id: 'nsc-7', zone: 'EAST', region: 'EAST 3', dealerCode: 'EAST 3RANI', dealerName: 'RANI', month: 'June', year: '2029', provisionalBand: 'NO BAND', evaluatedPoints: '0' },
    { id: 'nsc-8', zone: 'EAST', region: 'EAST 3', dealerCode: 'EAST 3RDMOT', dealerName: 'RD MOTORS', month: 'June', year: '2029', provisionalBand: 'NO BAND', evaluatedPoints: '0' },
    { id: 'nsc-9', zone: 'EAST', region: 'EAST 3', dealerCode: 'EAST 3SAIK', dealerName: 'SAIKIA', month: 'June', year: '2029', provisionalBand: 'NO BAND', evaluatedPoints: '0' },
    { id: 'nsc-10', zone: 'EAST', region: 'EAST 3', dealerCode: 'EAST 3SAMAD', dealerName: 'SAMADON', month: 'June', year: '2029', provisionalBand: 'NO BAND', evaluatedPoints: '0' },
  ];

  function readUser() {
    try {
      return JSON.parse(localStorage.getItem('bsc_user') || '{}');
    } catch (error) {
      return {};
    }
  }

  const user = readUser();
  const role = params.get('role') || user.role || 'admin';

  const roleHome = {
    admin: '/vanilla/admin/',
    msil: '/vanilla/msil/',
    dealer: '/vanilla/dealer/',
  };

  const elements = {
    pageTitle: document.getElementById('page-title'),
    summaryPanel: document.getElementById('summary-panel'),
    detailPanel: document.getElementById('detail-panel'),
    summaryRows: document.getElementById('summary-rows'),
    summaryCount: document.getElementById('summary-count'),
    downloadButton: document.getElementById('download-button'),
    summaryBackButton: document.getElementById('summary-back-button'),
    zoneFilter: document.getElementById('zone-filter'),
    regionFilter: document.getElementById('region-filter'),
    dealerFilter: document.getElementById('dealer-filter'),
    monthFilter: document.getElementById('month-filter'),
    yearFilter: document.getElementById('year-filter'),
  };

  function setText(selector, value) {
    const element = document.querySelector(selector);
    if (element) element.textContent = value;
  }

  function setOptions(select, values, allLabel) {
    select.innerHTML = `<option value="">${allLabel}</option>`;
    values.forEach((value) => {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = value;
      select.appendChild(option);
    });
  }

  function unique(key) {
    return [...new Set(demoScores.map((score) => score[key]).filter(Boolean))].sort();
  }

  function getFilteredScores() {
    const zone = elements.zoneFilter.value;
    const region = elements.regionFilter.value;
    const dealerText = elements.dealerFilter.value.trim().toLowerCase();
    const month = elements.monthFilter.value;
    const year = elements.yearFilter.value;

    return demoScores.filter((score) => {
      if (zone && score.zone !== zone) return false;
      if (region && score.region !== region) return false;
      if (month && score.month !== month) return false;
      if (year && score.year !== year) return false;
      if (dealerText) {
        const haystack = `${score.dealerCode} ${score.dealerName}`.toLowerCase();
        if (!haystack.includes(dealerText)) return false;
      }
      return true;
    });
  }

  function actionButtons(score) {
    const wrapper = document.createElement('div');
    wrapper.className = 'summary-action-group';

    const viewButton = document.createElement('button');
    viewButton.type = 'button';
    viewButton.className = 'table-action';
    viewButton.textContent = 'View';
    viewButton.addEventListener('click', () => showDetail(score, 'view'));
    wrapper.appendChild(viewButton);

    if (role === 'admin') {
      const editButton = document.createElement('button');
      editButton.type = 'button';
      editButton.className = 'table-action table-action--edit';
      editButton.textContent = 'Edit';
      editButton.addEventListener('click', () => showDetail(score, 'edit'));
      wrapper.appendChild(editButton);
    }

    return wrapper;
  }

  function renderSummary() {
    const scores = getFilteredScores();
    elements.summaryRows.innerHTML = '';

    scores.forEach((score, index) => {
      const row = document.createElement('tr');
      [
        index + 1,
        score.zone,
        score.region,
        score.dealerName,
        score.month,
        score.year,
        score.provisionalBand,
        score.evaluatedPoints,
      ].forEach((value) => {
        const cell = document.createElement('td');
        cell.textContent = value || '-';
        row.appendChild(cell);
      });

      const actionCell = document.createElement('td');
      actionCell.appendChild(actionButtons(score));
      row.appendChild(actionCell);
      elements.summaryRows.appendChild(row);
    });

    elements.summaryCount.textContent = `Showing ${scores.length} dealer${scores.length === 1 ? '' : 's'}`;
  }

  function fillTemplateValues(score) {
    const values = {
      region: score.region || '',
      dealerName: score.dealerName || '',
      dealerCode: score.dealerCode || '',
      provisionalPoints: score.evaluatedPoints || '0',
      evaluatedPoints: score.evaluatedPoints || '0',
      finalEvaluatedPoints: score.evaluatedPoints || '0',
      finalScore: score.evaluatedPoints || '0',
      provisionalBand: score.provisionalBand || '',
    };

    document.querySelectorAll('[data-nsc-field]').forEach((element) => {
      const key = element.dataset.nscField;
      element.textContent = values[key] ?? '';
      element.contentEditable = 'false';
    });
  }

  function showDetail(score, mode) {
    fillTemplateValues(score);
    elements.summaryPanel.hidden = true;
    elements.detailPanel.hidden = false;
    elements.downloadButton.hidden = false;
    elements.summaryBackButton.hidden = false;
    elements.pageTitle.textContent = mode === 'edit' ? 'Edit NSC Score page' : 'View NSC Score page';

    if (mode === 'edit') {
      document.querySelectorAll('[data-nsc-field]').forEach((element) => {
        element.contentEditable = 'true';
      });
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function showSummary() {
    elements.summaryPanel.hidden = false;
    elements.detailPanel.hidden = true;
    elements.downloadButton.hidden = true;
    elements.summaryBackButton.hidden = true;
    elements.pageTitle.textContent = 'View NSC Master Data';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function configureForRole() {
    document.querySelectorAll('[data-admin-only]').forEach((element) => {
      element.hidden = role !== 'admin';
    });
  }

  function bindEvents() {
    document.getElementById('logout-button')?.addEventListener('click', () => {
      localStorage.removeItem('bsc_token');
      localStorage.removeItem('bsc_user');
      sessionStorage.removeItem('bsc_safe_route_history');
      window.location.href = '/login';
    });

    document.querySelector('[data-go-bsc]')?.addEventListener('click', () => {
      window.location.href = roleHome[role] || '/vanilla/admin/';
    });

    document.querySelectorAll('[data-admin-section]').forEach((button) => {
      button.addEventListener('click', () => {
        const section = button.dataset.adminSection || 'bsc';
        sessionStorage.setItem('bsc_admin_section', section);
        window.location.href = `/vanilla/admin/?section=${encodeURIComponent(section)}`;
      });
    });

    document.getElementById('back-button')?.addEventListener('click', () => {
      if (!elements.detailPanel.hidden) {
        showSummary();
        return;
      }
      window.location.href = roleHome[role] || '/vanilla/admin/';
    });

    elements.summaryBackButton.addEventListener('click', showSummary);
    elements.downloadButton.addEventListener('click', () => window.print());

    [
      elements.zoneFilter,
      elements.regionFilter,
      elements.dealerFilter,
      elements.monthFilter,
      elements.yearFilter,
    ].forEach((element) => {
      element.addEventListener('input', renderSummary);
      element.addEventListener('change', renderSummary);
    });
  }

  setText('#user-name', user.dealerName || user.name || (role === 'msil' ? 'MSIL' : role === 'dealer' ? 'Dealer' : 'Admin'));
  setText('#user-code', user.dealerCode || user.mailId || role.toUpperCase());
  setOptions(elements.zoneFilter, unique('zone'), 'All Zones');
  setOptions(elements.regionFilter, unique('region'), 'All Regions');
  setOptions(elements.monthFilter, unique('month'), 'All Months');
  setOptions(elements.yearFilter, unique('year'), 'All Years');
  configureForRole();
  bindEvents();
  renderSummary();
})();
